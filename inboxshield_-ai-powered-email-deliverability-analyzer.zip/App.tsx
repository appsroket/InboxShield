import React, { useState, useCallback, useEffect } from 'react';
import { DnsCheckResult, DnsCheckStatus, DnsCheckType } from './types';
import { analyzeDnsRecord } from './services/geminiService';
import DnsCheckCard from './components/DnsCheckCard';
import Spinner from './components/Spinner';
import AnalysisModal from './components/AnalysisModal';
import CheckCircleIcon from './components/icons/CheckCircleIcon';
import XCircleIcon from './components/icons/XCircleIcon';
import AlertTriangleIcon from './components/icons/AlertTriangleIcon';
import AdBanner from './components/AdBanner';

// --- TYPES ---
interface AnalysisHistoryRecord {
  domain: string;
  dkimSelector?: string;
  results: DnsCheckResult[];
  timestamp: number;
}


// --- MAIN APP COMPONENT ---
const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [currentUser, setCurrentUser] = useState<{ email: string } | null>(null);
  const [currentPage, setCurrentPage] = useState<'analyzer' | 'dashboard'>('analyzer');
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);

  const handleLogin = (email: string) => {
    setIsAuthenticated(true);
    setCurrentUser({ email });
    setIsAuthModalOpen(false);
    setCurrentPage('dashboard');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setCurrentUser(null);
    setCurrentPage('analyzer');
  };

  const handleSaveAnalysis = (domain: string, dkimSelector: string, results: DnsCheckResult[]) => {
    if (!isAuthenticated || !currentUser) return;

    const newRecord: AnalysisHistoryRecord = {
      domain,
      dkimSelector,
      results,
      timestamp: Date.now(),
    };

    try {
      const existingHistoryJson = localStorage.getItem(`inboxshield_history_${currentUser.email}`);
      const existingHistory: AnalysisHistoryRecord[] = existingHistoryJson ? JSON.parse(existingHistoryJson) : [];
      const updatedHistory = [newRecord, ...existingHistory];
      localStorage.setItem(`inboxshield_history_${currentUser.email}`, JSON.stringify(updatedHistory));
    } catch (error) {
      console.error("Failed to save analysis to localStorage", error);
    }
  };

  return (
    <div className="min-h-screen bg-surface font-sans text-gray-800">
      <Header
        isAuthenticated={isAuthenticated}
        userEmail={currentUser?.email}
        onNavigate={setCurrentPage}
        onLoginClick={() => setIsAuthModalOpen(true)}
        onLogoutClick={handleLogout}
      />

      {currentPage === 'analyzer' && <AnalyzerView onAnalysisComplete={handleSaveAnalysis} />}
      {currentPage === 'dashboard' && isAuthenticated && currentUser && <DashboardView userEmail={currentUser.email} />}

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLogin={handleLogin}
      />
    </div>
  );
};

// --- HEADER COMPONENT ---
const Header: React.FC<{
  isAuthenticated: boolean;
  userEmail?: string;
  onNavigate: (page: 'analyzer' | 'dashboard') => void;
  onLoginClick: () => void;
  onLogoutClick: () => void;
}> = ({ isAuthenticated, userEmail, onNavigate, onLoginClick, onLogoutClick }) => {
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <button onClick={() => onNavigate('analyzer')} className="focus:outline-none">
            <h1 className="text-2xl font-bold text-secondary">
              InboxShield <span className="text-primary font-light">AI Analyzer</span>
            </h1>
          </button>
          <nav className="flex items-center space-x-4">
            {isAuthenticated ? (
              <>
                <button onClick={() => onNavigate('dashboard')} className="text-sm font-medium text-gray-600 hover:text-primary">Dashboard</button>
                <span className="text-sm text-gray-500">{userEmail}</span>
                <button onClick={onLogoutClick} className="text-sm font-medium text-gray-600 hover:text-primary">Logout</button>
              </>
            ) : (
              <button onClick={onLoginClick} className="px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-secondary hover:bg-opacity-90">
                Login / Sign Up
              </button>
            )}
          </nav>
        </div>
      </div>
    </header>
  );
};


// --- AUTH MODAL COMPONENT ---
const AuthModal: React.FC<{ isOpen: boolean; onClose: () => void; onLogin: (email: string) => void }> = ({ isOpen, onClose, onLogin }) => {
  const [email, setEmail] = useState('user@example.com');
  const [password, setPassword] = useState('password');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(email);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4">
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-sm">
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-xl font-bold text-secondary">Welcome Back</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">&times;</button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Email Address</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" required />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Password</label>
            <input type="password" value={password} onChange={e => setPassword(e.target.value)} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" required />
          </div>
          <p className="text-xs text-gray-500">This is a simulated login. Any email/password will work.</p>
          <button type="submit" className="w-full inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-primary hover:bg-opacity-90">
            Login
          </button>
        </form>
      </div>
    </div>
  );
};


// --- DASHBOARD VIEW COMPONENT ---
const DashboardView: React.FC<{ userEmail: string }> = ({ userEmail }) => {
    const [history, setHistory] = useState<AnalysisHistoryRecord[]>([]);
    const [selectedDomain, setSelectedDomain] = useState<string | null>(null);

    useEffect(() => {
        try {
            const savedHistoryJson = localStorage.getItem(`inboxshield_history_${userEmail}`);
            if (savedHistoryJson) {
                const savedHistory = JSON.parse(savedHistoryJson);
                setHistory(savedHistory);
                if (savedHistory.length > 0) {
                    const uniqueDomains = [...new Set(savedHistory.map(item => item.domain))];
                    setSelectedDomain(uniqueDomains[0]);
                }
            }
        } catch (error) {
            console.error("Failed to load history from localStorage", error);
        }
    }, [userEmail]);

    const uniqueDomains = [...new Set(history.map(item => item.domain))];
    const analysesForSelectedDomain = history.filter(item => item.domain === selectedDomain);

    const StatusIcon = ({ status }: { status: DnsCheckStatus }) => {
        switch (status) {
            case DnsCheckStatus.OK: return <CheckCircleIcon className="w-5 h-5 text-green-500" />;
            case DnsCheckStatus.NEEDS_FIX: return <XCircleIcon className="w-5 h-5 text-red-500" />;
            default: return <AlertTriangleIcon className="w-5 h-5 text-yellow-500" />;
        }
    };

    return (
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="text-center">
                <h2 className="text-4xl font-extrabold text-secondary tracking-tight">Your Dashboard</h2>
                <p className="mt-4 max-w-2xl mx-auto text-lg text-gray-600">
                    Review your past analyses and track your deliverability improvements.
                </p>
            </div>
            
            <AdBanner />

            {history.length === 0 ? (
                <div className="mt-10 text-center text-gray-500">
                    <p>You haven't analyzed any domains yet. Go to the analyzer to get started!</p>
                </div>
            ) : (
                <div className="mt-10 md:flex md:space-x-8">
                    <aside className="md:w-1/4">
                        <h3 className="text-lg font-semibold text-secondary mb-4">Your Domains</h3>
                        <ul className="space-y-2">
                            {uniqueDomains.map(domain => (
                                <li key={domain}>
                                    <button
                                        onClick={() => setSelectedDomain(domain)}
                                        className={`w-full text-left px-4 py-2 rounded-md text-sm font-medium transition-colors ${selectedDomain === domain ? 'bg-primary text-white' : 'bg-white hover:bg-gray-100'}`}
                                    >
                                        {domain}
                                    </button>
                                </li>
                            ))}
                        </ul>
                    </aside>
                    <section className="md:w-3/4 mt-8 md:mt-0">
                        {analysesForSelectedDomain.length > 0 && (
                             <h3 className="text-lg font-semibold text-secondary mb-4">Analysis History for {selectedDomain}</h3>
                        )}
                        <div className="space-y-6">
                            {analysesForSelectedDomain.map((record, index) => (
                                <div key={index} className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
                                    <p className="text-sm text-gray-500 mb-4 font-medium">
                                        {new Date(record.timestamp).toLocaleString()}
                                    </p>
                                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                                        {record.results.map(result => (
                                            <div key={result.type} className="flex items-center space-x-3">
                                                <StatusIcon status={result.status} />
                                                <div>
                                                    <p className="font-semibold text-gray-800">{result.type}</p>
                                                    <p className="text-xs text-gray-600">Status: {result.status.replace('_', ' ')}</p>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </section>
                </div>
            )}
        </main>
    );
};


// --- ANALYZER VIEW COMPONENT ---
const AnalyzerView: React.FC<{onAnalysisComplete: (domain: string, dkimSelector: string, results: DnsCheckResult[]) => void}> = ({ onAnalysisComplete }) => {
  const [domain, setDomain] = useState<string>('');
  const [dkimSelector, setDkimSelector] = useState<string>('');
  const [dmarcRuaEmail, setDmarcRuaEmail] = useState<string>('');
  const [dnsResults, setDnsResults] = useState<DnsCheckResult[] | null>(null);
  const [isLoadingDomain, setIsLoadingDomain] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [modalContent, setModalContent] = useState<string>('');
  const [isModalLoading, setIsModalLoading] = useState<boolean>(false);
  const [currentAnalysisType, setCurrentAnalysisType] = useState<DnsCheckType | null>(null);
  
  const [isUnsubscribeEnabled, setIsUnsubscribeEnabled] = useState<boolean>(false);

  // Helper function to contain all DMARC validation logic
  const validateDmarcRecord = (result: DnsCheckResult): DnsCheckResult => {
      const dmarcValue = result.value;
      const dmarcExplanation = `
        <br/><br/>
        <strong>What is DMARC?</strong>
        Domain-based Message Authentication, Reporting, and Conformance (DMARC) tells receiving email servers what to do with messages that fail SPF and DKIM checks. It also provides a way for you to get reports about your email's performance.
        <a href="https://support.google.com/a/answer/2466580" target="_blank" rel="noopener noreferrer" class="text-primary hover:underline font-medium">Learn more about DMARC</a>.
      `;

      if (!dmarcValue) {
        return {
          ...result,
          status: DnsCheckStatus.NEEDS_FIX,
          summary: `<b>DMARC record not found.</b> This is critical for preventing spoofing and monitoring your email deliverability.${dmarcExplanation}`,
          value: 'Not found',
        };
      }

      if (!dmarcValue.trim().startsWith('v=DMARC1;')) {
        return {
          ...result,
          status: DnsCheckStatus.NEEDS_FIX,
          summary: `<b>Invalid Format:</b> Your DMARC record is invalid because it does not start with "v=DMARC1;". This is a mandatory tag.${dmarcExplanation}`,
        };
      }

      if (!dmarcValue.includes('p=')) {
        return {
          ...result,
          status: DnsCheckStatus.NEEDS_FIX,
          summary: '<b>Missing Policy:</b> Your DMARC record is missing the mandatory policy tag (p=). This tells servers how to handle failed emails.',
        };
      }

      let policySummary = '';
      let reportingSummary = '';
      let finalStatus: DnsCheckStatus = DnsCheckStatus.OK;

      // Check reporting status
      const ruaMatch = dmarcValue.match(/rua=mailto:([^;]+)/);
      if (ruaMatch && ruaMatch[1]) {
        const reportingAddress = ruaMatch[1].trim();
        reportingSummary = `Excellent! DMARC reporting is enabled. Aggregate reports will be sent to <strong>${reportingAddress}</strong>.`;
      } else if (dmarcValue.includes('rua=')) {
        reportingSummary = `<b>Action Needed:</b> Your \`rua\` tag is present but seems to be malformed. It should be in the format \`rua=mailto:address@yourdomain.com\`.`;
        finalStatus = DnsCheckStatus.NEEDS_FIX;
      } else {
        reportingSummary = `<b>Action Needed:</b> Add a \`rua\` tag to receive aggregated reports. We suggest using an address like \`dmarc-reports@${domain}\`. Without reports, you can't monitor who is sending email on behalf of your domain.`;
        finalStatus = DnsCheckStatus.NEEDS_FIX;
      }

      // Check policy status
      const policyMatch = dmarcValue.match(/p=([a-zA-Z]+)/);
      const currentPolicy = policyMatch ? policyMatch[1].toLowerCase() : null;

      if (currentPolicy === 'reject') {
        policySummary = 'Excellent! Your DMARC policy is set to "reject", offering the strongest protection.';
      } else if (currentPolicy === 'quarantine') {
        policySummary = 'Good start. Your policy is "quarantine". For maximum protection, consider upgrading to "p=reject" after monitoring reports.';
        finalStatus = DnsCheckStatus.NEEDS_FIX;
      } else if (currentPolicy === 'none') {
        policySummary = 'Your policy is "none", which only monitors. For protection, upgrade to "p=quarantine" or "p=reject".';
        finalStatus = DnsCheckStatus.NEEDS_FIX;
      } else {
        policySummary = 'DMARC policy (p=) is present but has an invalid or unrecognized value.';
        finalStatus = DnsCheckStatus.NEEDS_FIX;
      }

      return {
        ...result,
        status: finalStatus,
        summary: `<p>${policySummary}</p><p class="mt-2">${reportingSummary}</p>${dmarcExplanation}`,
      };
    };

    const handleDmarcPolicyChange = (newPolicy: 'none' | 'quarantine' | 'reject') => {
        setDnsResults(prevResults => {
            if (!prevResults) return null;
            const newResults = prevResults.map(res => {
                if (res.type === DnsCheckType.DMARC) {
                    let newValue = res.value;
                    if(newValue.includes('p=')) {
                        newValue = res.value.replace(/p=([a-zA-Z]+)/, `p=${newPolicy}`);
                    } else if (newValue.includes('v=DMARC1;')) {
                        // Insert policy if it's missing entirely
                        newValue = newValue.replace('v=DMARC1;', `v=DMARC1; p=${newPolicy};`);
                    }
                    return validateDmarcRecord({ ...res, value: newValue });
                }
                return res;
            });
            onAnalysisComplete(domain, dkimSelector, newResults);
            return newResults;
        });
    };

  const handleDomainSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!domain) {
      setError('Please enter a domain name.');
      return;
    }
    setError(null);
    setIsLoadingDomain(true);
    setDnsResults(null);
    setIsUnsubscribeEnabled(false); // Reset on new submission

    // Simulate network delay for fetching DNS records
    setTimeout(() => {
      const dmarcValue = `v=DMARC1; p=none;${dmarcRuaEmail ? ` rua=mailto:${dmarcRuaEmail}` : ''}`;
      // Mock data based on a fictional domain
      const mockResults: DnsCheckResult[] = [
        {
          type: DnsCheckType.SPF,
          status: DnsCheckStatus.UNKNOWN,
          value: 'v=spf1 include:_spf.google.com include:sendgrid.net include:servers.mcsv.net a mx ptr include:thirdparty.com include:anothervendor.com include:yetanother.com include:andanother.net a:outbound.example.com redirect=_spf.example.com ~all',
          summary: 'Checking SPF configuration...',
        },
        {
          type: DnsCheckType.DKIM,
          status: DnsCheckStatus.UNKNOWN,
          value: 'v=DKIM1; k=rsa; p=MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA...',
          summary: `Checking DKIM for selector: ${dkimSelector || 'default'}...`,
        },
        {
          type: DnsCheckType.DMARC,
          status: DnsCheckStatus.UNKNOWN,
          value: dmarcValue,
          summary: 'Checking DMARC policy...',
        },
      ];
      
      const validatedResults = mockResults.map(result => {
        if (result.type === DnsCheckType.SPF) {
          const spfValue = result.value;
          const issues: string[] = [];
          const spfExplanation = `
            <br/><br/>
            <strong>What is SPF?</strong>
            Sender Policy Framework (SPF) is an email authentication standard that helps protect your domain from being used for email spoofing. A correct SPF record lists all the servers authorized to send emails on your behalf, improving your email deliverability.
            <a href="https://support.google.com/a/answer/33786" target="_blank" rel="noopener noreferrer" class="text-primary hover:underline font-medium">Learn more about SPF</a>.
          `;

          if (!spfValue || !spfValue.trim().toLowerCase().startsWith('v=spf1')) {
            return {
              ...result,
              status: DnsCheckStatus.NEEDS_FIX,
              summary: `SPF record is missing or invalid. It must start with "v=spf1".${spfExplanation}`,
            };
          }
          
          if ((spfValue.match(/v=spf1/gi) || []).length > 1) {
            return {
              ...result,
              status: DnsCheckStatus.NEEDS_FIX,
              summary: `<b>Critical Error:</b> Multiple 'v=spf1' entries found. A domain must have only one SPF TXT record.${spfExplanation}`,
            };
          }

          const isDnsLookupMechanism = (part: string): boolean => {
            const p = part.toLowerCase();
            // Mechanisms that are standalone keywords
            const standaloneLookups = ['a', 'mx', 'ptr'];
            if (standaloneLookups.includes(p)) return true;

            // Mechanisms that are prefixes. 'redirect' is a modifier but performs a lookup.
            const prefixLookups = ['include:', 'a:', 'mx:', 'ptr:', 'exists:', 'redirect='];
            return prefixLookups.some(prefix => p.startsWith(prefix));
          };

          const parts = spfValue.split(/\s+/);
          const lookupMechanisms = parts.filter(isDnsLookupMechanism);
          const totalLookups = lookupMechanisms.length;

          if (totalLookups > 10) {
            issues.push(`
              <b>Critical: Exceeds 10 DNS Lookups:</b> Your SPF record performs ${totalLookups} DNS lookups, which is over the hard limit of 10.
              <br/><br/>
              <strong>Why this is a problem:</strong> Email servers are required to stop evaluating SPF records after 10 DNS-querying mechanisms are seen. Any mechanisms after the 10th lookup will be ignored, which can cause legitimate emails to fail SPF authentication. This significantly harms your deliverability.
              <br/><br/>
              <strong>Mechanisms contributing to the lookup count (${totalLookups}):</strong>
              <ul class="list-disc list-inside mt-1">
                ${lookupMechanisms.map(m => `<li><code>${m}</code></li>`).join('')}
              </ul>
              <br/>
              <strong>How to fix:</strong> You must reduce the number of lookups. Common strategies include removing unnecessary 'include' statements, replacing mechanisms with specific IP addresses (using 'ip4:' or 'ip6:'), or using a third-party SPF flattening service.
            `);
          }
          
          const lowerSpfValue = spfValue.toLowerCase();
          if (lowerSpfValue.includes('~all')) {
            issues.push(`<b>Softfail Is Used:</b> Your record uses '~all' (Softfail). This allows potentially spoofed emails to still be delivered. For maximum protection, use '-all' (Hardfail).`);
          } else if (!lowerSpfValue.includes('-all')) {
            issues.push(`<b>Missing Terminator:</b> Your record is missing a required 'all' mechanism (like '-all' or '~all'). This makes the policy ineffective.`);
          }

          let summary = '';
          let status = DnsCheckStatus.OK;

          if (issues.length > 0) {
              status = DnsCheckStatus.NEEDS_FIX;
              summary = '<ul>' + issues.map(issue => `<li class="mb-2">${issue}</li>`).join('') + '</ul>';
          } else {
              summary = 'Excellent! Your SPF record is well-configured and uses the secure "-all" (Hardfail) mechanism.';
          }

          return { ...result, status, summary: summary + spfExplanation };
        }

        if (result.type === DnsCheckType.DKIM) {
          const dkimValue = result.value;
          const selector = dkimSelector || 'default';
          const dkimExplanation = `
            <br/><br/>
            <strong>What is DKIM?</strong>
            DomainKeys Identified Mail (DKIM) adds a digital signature to your emails. This signature is verified by the recipient's email server using a public key published in your DNS. It proves that the email came from your domain and hasn't been altered in transit.
            <a href="https://support.google.com/a/answer/174124" target="_blank" rel="noopener noreferrer" class="text-primary hover:underline font-medium">Learn more about DKIM</a>.
          `;

          if (!dkimValue || dkimValue === 'Not found') {
            return {
              ...result, status: DnsCheckStatus.NEEDS_FIX,
              summary: `<b>No DKIM record found for selector: \`${selector}\`.</b> A DKIM record is crucial for verifying that an email was sent by you and that its content hasn't been tampered with.${dkimExplanation}`,
              value: 'Not found',
            };
          }

          if (!dkimValue.trim().startsWith('v=DKIM1;')) {
            return {
              ...result, status: DnsCheckStatus.NEEDS_FIX,
              summary: `<b>Invalid Format:</b> Your DKIM record is invalid because it does not start with \`v=DKIM1;\`. This version tag is mandatory.${dkimExplanation}`,
            };
          }

          if (!dkimValue.includes('k=')) {
            return {
              ...result, status: DnsCheckStatus.NEEDS_FIX,
              summary: `<b>Missing Key Type:</b> Your DKIM record is missing the required key type tag (e.g., \`k=rsa\`). This tag specifies the algorithm used to generate the key.${dkimExplanation}`,
            };
          }

          if (!dkimValue.includes('p=')) {
            return {
              ...result, status: DnsCheckStatus.NEEDS_FIX,
              summary: `<b>Missing Public Key:</b> Your DKIM record is missing the public key data tag (\`p=\`). This tag contains the public key that receiving mail servers use to verify your email's signature.${dkimExplanation}`,
            };
          }
          
          return {
            ...result, status: DnsCheckStatus.OK,
            summary: `A valid DKIM public key was found for selector: \`${selector}\`. This helps protect your emails from being marked as spam.${dkimExplanation}`,
          };
        }

        if (result.type === DnsCheckType.DMARC) {
          return validateDmarcRecord(result);
        }

        return result;
      });

      setDnsResults(validatedResults);
      onAnalysisComplete(domain, dkimSelector, validatedResults);
      setIsLoadingDomain(false);
    }, 1500);
  };

  const handleAnalyzeClick = useCallback(async (type: DnsCheckType, value: string) => {
    setCurrentAnalysisType(type);
    setIsModalOpen(true);
    setIsModalLoading(true);
    setModalContent('');
    
    const analysis = await analyzeDnsRecord(type, value);
    setModalContent(analysis);
    setIsModalLoading(false);
  }, []);
  
  // Interactive component for changing DMARC policy
  const DmarcPolicyChanger: React.FC<{ result: DnsCheckResult; onPolicyChange: (policy: 'none' | 'quarantine' | 'reject') => void }> = ({ result, onPolicyChange }) => {
    const policyMatch = result.value.match(/p=([a-zA-Z]+)/);
    const currentPolicy = policyMatch ? policyMatch[1].toLowerCase() : null;

    if (!currentPolicy || currentPolicy === 'reject') {
      return null;
    }

    const policies = [
      { id: 'none', name: 'Monitor (p=none)', description: "Emails that fail checks are delivered normally. Good for initial setup and monitoring." },
      { id: 'quarantine', name: 'Quarantine (p=quarantine)', description: "Emails that fail checks are sent to the recipient's spam folder." },
      { id: 'reject', name: 'Reject (p=reject)', description: "Emails that fail checks are blocked entirely. This offers the best protection." },
    ];

    return (
      <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <h4 className="font-bold text-secondary">Upgrade Your DMARC Policy</h4>
        <p className="text-sm text-gray-600 mt-1">
          Your current policy is <strong>{currentPolicy}</strong>. For better protection against spoofing, select a stricter policy below.
        </p>
        <div className="mt-3 space-y-2">
          {policies.map(policy => (
            <button
              key={policy.id}
              onClick={() => onPolicyChange(policy.id as 'none' | 'quarantine' | 'reject')}
              disabled={currentPolicy === policy.id}
              className={`w-full text-left p-3 rounded-md transition-all duration-200 ease-in-out border ${
                currentPolicy === policy.id
                  ? 'bg-secondary text-white border-secondary cursor-default'
                  : 'bg-white hover:bg-gray-50 hover:border-primary border-gray-300'
              }`}
            >
              <p className="font-semibold">{policy.name}</p>
              <p className="text-xs">{policy.description}</p>
            </button>
          ))}
        </div>
      </div>
    );
  };


  return (
    <>
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center">
          <h2 className="text-4xl font-extrabold text-secondary tracking-tight">
            Stop guessing, start delivering.
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-lg text-gray-600">
            Enter your domain to instantly check your email authentication records. Our AI will give you clear, actionable steps to improve your deliverability.
          </p>
        </div>

        <AdBanner />

        <div className="mt-10 max-w-xl mx-auto">
          <form onSubmit={handleDomainSubmit} className="flex flex-col sm:flex-row sm:items-start sm:gap-2">
            <div className="flex-grow space-y-2">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <input
                  type="text"
                  value={domain}
                  onChange={(e) => setDomain(e.target.value)}
                  placeholder="yourdomain.com"
                  required
                  className="w-full sm:col-span-2 px-4 py-3 border border-gray-300 rounded-md shadow-sm focus:ring-primary focus:border-primary placeholder-gray-400"
                  aria-label="Domain Name"
                />
                <input
                  type="text"
                  value={dkimSelector}
                  onChange={(e) => setDkimSelector(e.target.value)}
                  placeholder="selector (optional)"
                  className="w-full px-4 py-3 border border-gray-300 rounded-md shadow-sm focus:ring-primary focus:border-primary placeholder-gray-400"
                  aria-label="DKIM Selector"
                />
              </div>
              <input
                type="email"
                value={dmarcRuaEmail}
                onChange={(e) => setDmarcRuaEmail(e.target.value)}
                placeholder="DMARC report email (rua=) (optional)"
                className="w-full px-4 py-3 border border-gray-300 rounded-md shadow-sm focus:ring-primary focus:border-primary placeholder-gray-400"
                aria-label="DMARC Report Email"
              />
            </div>
            <button
              type="submit"
              disabled={isLoadingDomain}
              className="mt-3 sm:mt-0 w-full sm:w-auto flex-shrink-0 inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-primary hover:bg-opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary disabled:bg-opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {isLoadingDomain ? <Spinner className="w-5 h-5" /> : 'Analyze Domain'}
            </button>
          </form>
          {error && <p className="mt-2 text-sm text-red-600">{error}</p>}
        </div>

        {isLoadingDomain && (
          <div className="mt-12 flex justify-center">
            <div className="flex flex-col items-center">
              <Spinner className="w-12 h-12 text-primary" />
              <p className="mt-4 text-gray-600">Scanning DNS records...</p>
            </div>
          </div>
        )}

        {dnsResults && (
          <>
            <div className="mt-12">
              <h3 className="text-2xl font-bold text-center text-secondary">Analysis for {domain}</h3>
              <div className="mt-8 grid gap-8 md:grid-cols-2 lg:grid-cols-3 md:items-start">
                {dnsResults.map((result) => {
                  let messageBelowCard = null;
                  let summaryForCard = result.summary;

                  if (result.status === DnsCheckStatus.NEEDS_FIX) {
                    summaryForCard = 'Action recommended. See details below.';
                    messageBelowCard = <div className="mt-2 text-sm prose prose-sm max-w-none text-red-700" dangerouslySetInnerHTML={{ __html: result.summary }}></div>;
                  } else if (result.status === DnsCheckStatus.OK) {
                    summaryForCard = result.summary.split('<br/>')[0];
                    messageBelowCard = <div className="mt-2 text-sm prose prose-sm max-w-none text-gray-700" dangerouslySetInnerHTML={{ __html: result.summary }}></div>;
                  }

                  const cardResult = { ...result, summary: summaryForCard };

                  return (
                    <div key={result.type}>
                      <DnsCheckCard result={cardResult} onAnalyze={handleAnalyzeClick} />
                      {messageBelowCard}
                      {result.type === DnsCheckType.DMARC && <DmarcPolicyChanger result={result} onPolicyChange={handleDmarcPolicyChange} />}
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="mt-16 max-w-3xl mx-auto">
              <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
                <h3 className="text-2xl font-bold text-center text-secondary">Enable One-Click Unsubscribe</h3>
                <p className="mt-2 text-center text-gray-600">
                  Comply with sender requirements from Google and Yahoo by adding a one-click unsubscribe header to all outgoing emails.
                </p>
                <div className="mt-6 flex items-center justify-center">
                  <label htmlFor="unsubscribe-toggle" className="flex items-center cursor-pointer">
                    <span className="mr-3 text-gray-700 font-medium">Add Unsubscribe Headers</span>
                    <div className="relative">
                      <input 
                        type="checkbox" 
                        id="unsubscribe-toggle" 
                        className="sr-only" 
                        checked={isUnsubscribeEnabled}
                        onChange={() => setIsUnsubscribeEnabled(!isUnsubscribeEnabled)}
                      />
                      <div className={`block w-14 h-8 rounded-full transition-colors ${isUnsubscribeEnabled ? 'bg-secondary' : 'bg-gray-200'}`}></div>
                      <div className={`absolute left-1 top-1 bg-white w-6 h-6 rounded-full transition-transform ${isUnsubscribeEnabled ? 'translate-x-6' : ''}`}></div>
                    </div>
                  </label>
                </div>

                {isUnsubscribeEnabled && (
                  <div className="mt-6 bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-gray-700">Header Preview:</h4>
                    <p className="mt-2 text-sm text-gray-600">
                      When enabled, the following headers will be automatically added to your emails:
                    </p>
                    <div className="mt-3 space-y-2">
                      <div>
                        <p className="text-xs text-gray-500 font-semibold">List-Unsubscribe:</p>
                        <code className="text-xs text-gray-800 break-all">{`<mailto:unsubscribe@${domain}>`}</code>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500 font-semibold">List-Unsubscribe-Post:</p>
                        <code className="text-xs text-gray-800 break-all">List-Unsubscribe=One-Click</code>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </>
        )}
      </main>

      <AnalysisModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={currentAnalysisType}
        content={modalContent}
        isLoading={isModalLoading}
      />
    </>
  );
};

export default App;
