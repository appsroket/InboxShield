
import { GoogleGenAI } from "@google/genai";
import { DnsCheckType } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("API_KEY environment variable not set. Gemini API calls will fail.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export const analyzeDnsRecord = async (recordType: DnsCheckType, recordValue: string): Promise<string> => {
  if (!API_KEY) {
    return Promise.resolve("Error: Gemini API key is not configured. Please set the `process.env.API_KEY` environment variable.");
  }
  
  const prompt = `
    You are an expert in email deliverability and DNS configuration, acting as the AI engine for an app called InboxShield.
    Your task is to analyze the following ${recordType} record and provide a clear, concise, and actionable report for a non-technical user like a small business owner or coach.

    **Record Type:** ${recordType}
    **Record Value:** \`${recordValue}\`

    Please structure your response in Markdown format with the following sections:

    ### 1. Overall Assessment
    Start with a one-sentence summary of the record's health (e.g., "This SPF record is well-configured but could be more secure," or "This DMARC policy is not providing any protection and needs immediate attention.").

    ### 2. What this record does
    Briefly explain the purpose of this ${recordType} record in simple terms.

    ### 3. Detailed Analysis
    - Break down the components of the record value. For example, for SPF, explain what 'v=spf1', 'include:', 'a', 'mx', and '~all' mean.
    - Point out any specific strengths or weaknesses.
    - For DMARC, explain the meaning of the 'p', 'rua', and 'pct' tags.
    - For DKIM, explain its role even though the value is just a public key.

    ### 4. Actionable Recommendations
    - Provide a clear, numbered list of recommendations.
    - If the record is good, suggest potential improvements for hardening security (e.g., moving from \`~all\` to \`-all\` in SPF, or moving from \`p=none\` to \`p=quarantine\`).
    - If the record is bad, provide the exact corrected record string the user should copy and paste into their DNS settings.
    - Keep the tone helpful, encouraging, and clear. Avoid overly technical jargon where possible.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    return "An error occurred while analyzing the record. Please check the console for details.";
  }
};
