
export enum DnsCheckType {
  SPF = 'SPF',
  DKIM = 'DKIM',
  DMARC = 'DMARC',
}

export enum DnsCheckStatus {
  OK = 'ok',
  NEEDS_FIX = 'needs_fix',
  UNKNOWN = 'unknown',
}

export interface DnsCheckResult {
  type: DnsCheckType;
  status: DnsCheckStatus;
  value: string;
  summary: string;
}
