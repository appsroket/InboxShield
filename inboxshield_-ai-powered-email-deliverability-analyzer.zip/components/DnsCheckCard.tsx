
import React from 'react';
import { DnsCheckResult, DnsCheckStatus, DnsCheckType } from '../types';
import CheckCircleIcon from './icons/CheckCircleIcon';
import XCircleIcon from './icons/XCircleIcon';
import AlertTriangleIcon from './icons/AlertTriangleIcon';
import SparklesIcon from './icons/SparklesIcon';

interface DnsCheckCardProps {
  result: DnsCheckResult;
  onAnalyze: (type: DnsCheckType, value: string) => void;
}

const statusConfig = {
  [DnsCheckStatus.OK]: {
    text: 'Passing',
    Icon: CheckCircleIcon,
    badgeClasses: 'bg-green-100 text-green-800',
    iconClasses: 'text-green-500',
  },
  [DnsCheckStatus.NEEDS_FIX]: {
    text: 'Needs Fix',
    Icon: XCircleIcon,
    badgeClasses: 'bg-red-100 text-red-800',
    iconClasses: 'text-red-500',
  },
  [DnsCheckStatus.UNKNOWN]: {
    text: 'Unknown',
    Icon: AlertTriangleIcon,
    badgeClasses: 'bg-yellow-100 text-yellow-800',
    iconClasses: 'text-yellow-500',
  },
};

const DnsCheckCard: React.FC<DnsCheckCardProps> = ({ result, onAnalyze }) => {
  const config = statusConfig[result.status];

  return (
    <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200 flex flex-col justify-between">
      <div>
        <div className="flex justify-between items-start">
          <h3 className="text-lg font-bold text-secondary">{result.type} Record</h3>
          <span
            className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.badgeClasses}`}
          >
            <config.Icon className="w-4 h-4 mr-1.5" />
            {config.text}
          </span>
        </div>
        <p className="mt-2 text-sm text-gray-600">{result.summary}</p>
        <div className="mt-4 bg-gray-50 p-3 rounded-md">
          <p className="text-xs text-gray-500 font-semibold">Detected Value:</p>
          <code className="text-xs text-gray-800 break-all">{result.value || 'Not found'}</code>
        </div>
      </div>
      <div className="mt-6">
        <button
          onClick={() => onAnalyze(result.type, result.value)}
          className="w-full inline-flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-secondary hover:bg-opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition-colors"
        >
          <SparklesIcon className="w-5 h-5 mr-2" />
          Analyze with AI
        </button>
      </div>
    </div>
  );
};

export default DnsCheckCard;
