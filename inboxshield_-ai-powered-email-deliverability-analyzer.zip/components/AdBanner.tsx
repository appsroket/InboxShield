import React, { useState, useEffect } from 'react';

// Define the structure of a single ad
interface Ad {
  id: number;
  title: string;
  description: string;
  cta: string;
  link: string;
  color: string; // To simulate different ad creatives
}

// A list of mock ads to display
const mockAds: Ad[] = [
  {
    id: 1,
    title: 'SuperCharge Your SEO',
    description: 'Get to the first page of Google. Our AI tools boost your ranking.',
    cta: 'Learn More',
    link: '#',
    color: 'bg-blue-500',
  },
  {
    id: 2,
    title: 'Cloud Hosting Made Simple',
    description: 'Blazing fast, secure, and reliable hosting for your website.',
    cta: 'Get Started',
    link: '#',
    color: 'bg-green-500',
  },
  {
    id: 3,
    title: 'The Ultimate Design Toolkit',
    description: 'Access thousands of icons, fonts, and templates for your next project.',
    cta: 'Explore Now',
    link: '#',
    color: 'bg-purple-500',
  },
];

const AdBanner: React.FC = () => {
  const [currentAd, setCurrentAd] = useState<Ad | null>(null);

  useEffect(() => {
    // Select a random ad when the component mounts
    const randomAd = mockAds[Math.floor(Math.random() * mockAds.length)];
    setCurrentAd(randomAd);
  }, []);

  if (!currentAd) {
    return null; // Don't render if no ad is selected
  }

  return (
    <div className="my-8 max-w-4xl mx-auto">
      <div className="relative bg-white border border-gray-200 rounded-lg shadow-sm p-6">
        <span className="absolute top-2 right-2 text-xs text-gray-400 font-semibold bg-gray-100 px-2 py-1 rounded">Ad</span>
        <a href={currentAd.link} target="_blank" rel="noopener noreferrer" className="flex flex-col sm:flex-row items-center gap-6 group">
          <div className={`w-20 h-20 rounded-md flex-shrink-0 ${currentAd.color} flex items-center justify-center`}>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <div className="flex-grow text-center sm:text-left">
            <h4 className="font-bold text-lg text-secondary group-hover:text-primary transition-colors">{currentAd.title}</h4>
            <p className="text-sm text-gray-600 mt-1">{currentAd.description}</p>
          </div>
          <div className="mt-4 sm:mt-0 sm:ml-auto">
             <button className="px-5 py-2.5 border border-transparent text-sm font-medium rounded-md text-white bg-primary hover:bg-opacity-90 transition-colors">
                {currentAd.cta}
             </button>
          </div>
        </a>
      </div>
    </div>
  );
};

export default AdBanner;
